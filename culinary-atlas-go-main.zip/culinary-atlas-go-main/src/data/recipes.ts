// Recipe data with detailed nutrition information
export interface NutritionInfo {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  sodium: number;
}

export interface Recipe {
  id: string;
  name: string;
  cuisine: string;
  image: string;
  prepTime: number; // in minutes
  cookTime: number; // in minutes
  servings: number;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  description: string;
  ingredients: string[];
  instructions: string[];
  nutrition: NutritionInfo; // per serving
  tags: string[];
  rating: number; // out of 5
  reviews: number;
}

export const recipes: Recipe[] = [
  {
    id: '1',
    name: 'Butter Chicken',
    cuisine: 'Indian',
    image: 'indian-cuisine',
    prepTime: 20,
    cookTime: 40,
    servings: 4,
    difficulty: 'Medium',
    description: 'Creamy, rich Indian curry with tender chicken pieces in a tomato-based sauce with aromatic spices.',
    ingredients: [
      '500g chicken breast, cubed',
      '2 tbsp butter',
      '1 onion, finely chopped',
      '3 cloves garlic, minced',
      '1 tbsp ginger paste',
      '400ml tomato puree',
      '200ml heavy cream',
      '2 tsp garam masala',
      '1 tsp turmeric',
      '1 tsp cumin',
      'Fresh cilantro for garnish',
      'Salt to taste'
    ],
    instructions: [
      'Marinate chicken with yogurt, turmeric, and salt for 30 minutes',
      'Heat butter in a large pan and sauté onions until golden',
      'Add garlic and ginger, cook for 2 minutes',
      'Add spices and cook for 1 minute until fragrant',
      'Add tomato puree and simmer for 10 minutes',
      'Add marinated chicken and cook for 15-20 minutes',
      'Stir in heavy cream and simmer for 5 minutes',
      'Garnish with fresh cilantro and serve with rice or naan'
    ],
    nutrition: {
      calories: 425,
      protein: 35,
      carbs: 18,
      fat: 25,
      fiber: 4,
      sodium: 680
    },
    tags: ['High-Protein', 'Spicy', 'Comfort Food'],
    rating: 4.8,
    reviews: 342
  },
  {
    id: '2',
    name: 'Spaghetti Carbonara',
    cuisine: 'Italian',
    image: 'italian-cuisine',
    prepTime: 10,
    cookTime: 20,
    servings: 4,
    difficulty: 'Easy',
    description: 'Classic Roman pasta dish with eggs, cheese, pancetta, and black pepper.',
    ingredients: [
      '400g spaghetti',
      '200g pancetta or guanciale, diced',
      '4 large eggs',
      '100g Pecorino Romano cheese, grated',
      '50g Parmesan cheese, grated',
      'Black pepper, freshly ground',
      'Salt for pasta water'
    ],
    instructions: [
      'Bring a large pot of salted water to boil and cook spaghetti according to package directions',
      'While pasta cooks, fry pancetta in a large pan until crispy',
      'In a bowl, whisk together eggs, Pecorino, Parmesan, and black pepper',
      'Reserve 1 cup of pasta water before draining',
      'Add hot drained pasta to the pancetta pan (off heat)',
      'Quickly mix in egg mixture, adding pasta water to create a creamy sauce',
      'Toss continuously to avoid scrambling the eggs',
      'Serve immediately with extra cheese and black pepper'
    ],
    nutrition: {
      calories: 520,
      protein: 28,
      carbs: 52,
      fat: 22,
      fiber: 3,
      sodium: 890
    },
    tags: ['Quick', 'Comfort Food', 'Traditional'],
    rating: 4.7,
    reviews: 528
  },
  {
    id: '3',
    name: 'Pad Thai',
    cuisine: 'Thai',
    image: 'thai-cuisine',
    prepTime: 15,
    cookTime: 15,
    servings: 2,
    difficulty: 'Medium',
    description: 'Famous Thai stir-fried noodles with shrimp, peanuts, and tangy tamarind sauce.',
    ingredients: [
      '200g rice noodles',
      '200g shrimp, peeled and deveined',
      '2 eggs',
      '3 cloves garlic, minced',
      '100g bean sprouts',
      '2 spring onions, chopped',
      '50g roasted peanuts, crushed',
      '3 tbsp tamarind paste',
      '2 tbsp fish sauce',
      '2 tbsp palm sugar',
      '1 tbsp vegetable oil',
      'Lime wedges for serving'
    ],
    instructions: [
      'Soak rice noodles in warm water for 20-30 minutes until soft',
      'Mix tamarind paste, fish sauce, and palm sugar for the sauce',
      'Heat oil in a wok over high heat',
      'Stir-fry garlic until fragrant, add shrimp and cook until pink',
      'Push shrimp to the side, scramble eggs in the wok',
      'Add drained noodles and sauce, toss to combine',
      'Add bean sprouts and spring onions, stir-fry for 2 minutes',
      'Serve topped with crushed peanuts and lime wedges'
    ],
    nutrition: {
      calories: 485,
      protein: 32,
      carbs: 58,
      fat: 16,
      fiber: 4,
      sodium: 1240
    },
    tags: ['Seafood', 'Spicy', 'Street Food'],
    rating: 4.6,
    reviews: 412
  },
  {
    id: '4',
    name: 'Chicken Tacos',
    cuisine: 'Mexican',
    image: 'mexican-cuisine',
    prepTime: 15,
    cookTime: 20,
    servings: 4,
    difficulty: 'Easy',
    description: 'Flavorful Mexican tacos with seasoned chicken, fresh toppings, and zesty salsa.',
    ingredients: [
      '500g chicken breast, diced',
      '8 corn tortillas',
      '2 tsp chili powder',
      '1 tsp cumin',
      '1 tsp paprika',
      '1/2 tsp garlic powder',
      '1 onion, diced',
      '2 tomatoes, diced',
      '1 avocado, sliced',
      'Fresh cilantro, chopped',
      'Lime wedges',
      'Sour cream',
      'Shredded lettuce',
      'Cheese, shredded'
    ],
    instructions: [
      'Season chicken with chili powder, cumin, paprika, and garlic powder',
      'Heat oil in a pan and cook chicken until golden and cooked through',
      'Warm tortillas in a dry pan or microwave',
      'Dice tomatoes and onions for salsa',
      'Slice avocado and prepare other toppings',
      'Assemble tacos with chicken, lettuce, tomatoes, onions',
      'Top with avocado, cheese, sour cream, and cilantro',
      'Serve with lime wedges on the side'
    ],
    nutrition: {
      calories: 380,
      protein: 32,
      carbs: 35,
      fat: 14,
      fiber: 8,
      sodium: 420
    },
    tags: ['Quick', 'Family-Friendly', 'High-Fiber'],
    rating: 4.5,
    reviews: 298
  },
  {
    id: '5',
    name: 'Sushi Rolls',
    cuisine: 'Japanese',
    image: 'japanese-cuisine',
    prepTime: 30,
    cookTime: 20,
    servings: 4,
    difficulty: 'Hard',
    description: 'Traditional Japanese sushi rolls with fresh fish, vegetables, and perfectly seasoned rice.',
    ingredients: [
      '400g sushi rice',
      '450ml water',
      '60ml rice vinegar',
      '2 tbsp sugar',
      '1 tsp salt',
      '200g fresh salmon, thinly sliced',
      '200g fresh tuna, thinly sliced',
      '1 cucumber, julienned',
      '1 avocado, sliced',
      '6 nori sheets',
      'Pickled ginger',
      'Wasabi',
      'Soy sauce'
    ],
    instructions: [
      'Rinse sushi rice until water runs clear, then cook according to package',
      'Mix rice vinegar, sugar, and salt, then fold into hot cooked rice',
      'Let rice cool to room temperature',
      'Place nori sheet on bamboo mat, shiny side down',
      'Spread thin layer of rice on nori, leaving 1 inch at top',
      'Place fish and vegetables in a line across the center',
      'Roll tightly using the bamboo mat',
      'Slice into 6-8 pieces with a sharp, wet knife',
      'Serve with soy sauce, wasabi, and pickled ginger'
    ],
    nutrition: {
      calories: 320,
      protein: 18,
      carbs: 52,
      fat: 8,
      fiber: 3,
      sodium: 680
    },
    tags: ['Seafood', 'Low-Fat', 'Traditional'],
    rating: 4.9,
    reviews: 567
  },
  {
    id: '6',
    name: 'Chow Mein',
    cuisine: 'Chinese',
    image: 'chinese-cuisine',
    prepTime: 15,
    cookTime: 15,
    servings: 4,
    difficulty: 'Easy',
    description: 'Classic Chinese stir-fried noodles with vegetables and savory sauce.',
    ingredients: [
      '400g egg noodles',
      '200g chicken breast, sliced',
      '2 carrots, julienned',
      '1 bell pepper, sliced',
      '200g cabbage, shredded',
      '3 cloves garlic, minced',
      '2 tbsp soy sauce',
      '1 tbsp oyster sauce',
      '1 tbsp sesame oil',
      '2 tbsp vegetable oil',
      'Spring onions for garnish'
    ],
    instructions: [
      'Cook noodles according to package directions, drain and set aside',
      'Heat vegetable oil in a wok over high heat',
      'Stir-fry chicken until cooked through, remove and set aside',
      'Add garlic, carrots, and bell pepper, stir-fry for 3 minutes',
      'Add cabbage and cook until slightly wilted',
      'Return chicken to wok, add noodles',
      'Pour in soy sauce, oyster sauce, and sesame oil',
      'Toss everything together for 2-3 minutes',
      'Garnish with spring onions and serve hot'
    ],
    nutrition: {
      calories: 440,
      protein: 24,
      carbs: 54,
      fat: 15,
      fiber: 5,
      sodium: 920
    },
    tags: ['Quick', 'Stir-Fry', 'Weeknight Dinner'],
    rating: 4.4,
    reviews: 389
  }
];

// Helper function to get recipes by cuisine
export const getRecipesByCuisine = (cuisine: string): Recipe[] => {
  return recipes.filter(recipe => recipe.cuisine.toLowerCase() === cuisine.toLowerCase());
};

// Helper function to get recipe by ID
export const getRecipeById = (id: string): Recipe | undefined => {
  return recipes.find(recipe => recipe.id === id);
};

// Get all unique cuisines
export const getAllCuisines = (): string[] => {
  return Array.from(new Set(recipes.map(recipe => recipe.cuisine)));
};
