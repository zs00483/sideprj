// Recipe detail page with full information and ordering option
import { useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { getRecipeById } from "@/data/recipes";
import Header from "@/components/Header";
import OrderForm from "@/components/OrderForm";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Clock,
  Users,
  ChefHat,
  Star,
  ArrowLeft,
  MapPin,
  ShoppingBag,
} from "lucide-react";
import { toast } from "sonner";

// Mock restaurant data
const mockRestaurants = [
  {
    id: "1",
    name: "Tasty Bites",
    distance: "0.5 mi",
    rating: 4.5,
    deliveryTime: "25-35 min",
    price: "$$",
  },
  {
    id: "2",
    name: "World Kitchen",
    distance: "0.8 mi",
    rating: 4.7,
    deliveryTime: "30-40 min",
    price: "$$$",
  },
  {
    id: "3",
    name: "Global Flavors",
    distance: "1.2 mi",
    rating: 4.3,
    deliveryTime: "35-45 min",
    price: "$$",
  },
];

const RecipeDetail = () => {
  const navigate = useNavigate();
  
  // Get recipe ID from URL params
  const { id } = useParams<{ id: string }>();
  const recipe = getRecipeById(id || "");
  
  // State for ordering flow
  const [showOrderForm, setShowOrderForm] = useState(false);
  const [selectedRestaurant, setSelectedRestaurant] = useState<typeof mockRestaurants[0] | null>(null);

  // If recipe not found, show error
  if (!recipe) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-4">Recipe Not Found</h1>
          <Link to="/recipes">
            <Button>Browse Recipes</Button>
          </Link>
        </div>
      </div>
    );
  }

  // Get image path
  const getImagePath = () => {
    try {
      return new URL(`../assets/${recipe.image}.jpg`, import.meta.url).href;
    } catch {
      return "";
    }
  };

  // Handle restaurant selection - show order form
  const handleRestaurantSelect = (restaurant: typeof mockRestaurants[0]) => {
    setSelectedRestaurant(restaurant);
    setShowOrderForm(true);
  };
  
  // Handle back to restaurant list
  const handleBackToRestaurants = () => {
    setShowOrderForm(false);
    setSelectedRestaurant(null);
  };
  
  // Handle order completion
  const handleOrderComplete = () => {
    setShowOrderForm(false);
    setSelectedRestaurant(null);
    // Navigate back to recipes after a short delay
    setTimeout(() => {
      navigate("/recipes");
    }, 2000);
  };

  return (
    <div className="minscreen bg-background pb-12">
      {/* Header with logo */}
      <Header />
      
      {/* Back button */}
      <div className="container mx-auto px-4 py-6">
        <Link to="/recipes">
          <Button variant="ghost" className="gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Recipes
          </Button>
        </Link>
      </div>

      {/* Recipe header with image */}
      <div className="relative h-[400px] w-full">
        <img
          src={getImagePath()}
          alt={recipe.name}
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
        
        {/* Recipe title overlay */}
        <div className="absolute bottom-0 left-0 right-0 container mx-auto px-4 pb-8">
          <div className="flex flex-wrap gap-2 mb-4">
            <Badge className="bg-primary text-primary-foreground">
              {recipe.cuisine}
            </Badge>
            <Badge variant="secondary">{recipe.difficulty}</Badge>
            {recipe.tags.map((tag) => (
              <Badge key={tag} variant="outline">
                {tag}
              </Badge>
            ))}
          </div>
          <h1 className="text-5xl font-bold text-white mb-2">{recipe.name}</h1>
          <p className="text-xl text-white/90">{recipe.description}</p>
        </div>
      </div>

      {/* Main content */}
      <div className="container mx-auto px-4 mt-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left column - Recipe details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Quick info cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <Card>
                <CardContent className="pt-6 text-center">
                  <Clock className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <p className="text-sm text-muted-foreground">Total Time</p>
                  <p className="text-xl font-bold">
                    {recipe.prepTime + recipe.cookTime}min
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6 text-center">
                  <Users className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <p className="text-sm text-muted-foreground">Servings</p>
                  <p className="text-xl font-bold">{recipe.servings}</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6 text-center">
                  <ChefHat className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <p className="text-sm text-muted-foreground">Difficulty</p>
                  <p className="text-xl font-bold">{recipe.difficulty}</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6 text-center">
                  <Star className="h-8 w-8 mx-auto mb-2 text-primary fill-current" />
                  <p className="text-sm text-muted-foreground">Rating</p>
                  <p className="text-xl font-bold">{recipe.rating}</p>
                </CardContent>
              </Card>
            </div>

            {/* Ingredients */}
            <Card>
              <CardHeader>
                <CardTitle>Ingredients</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {recipe.ingredients.map((ingredient, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <span className="text-primary mt-1.5">•</span>
                      <span>{ingredient}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Instructions */}
            <Card>
              <CardHeader>
                <CardTitle>Instructions</CardTitle>
              </CardHeader>
              <CardContent>
                <ol className="space-y-4">
                  {recipe.instructions.map((instruction, index) => (
                    <li key={index} className="flex gap-4">
                      <span className="flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground font-bold">
                        {index + 1}
                      </span>
                      <p className="pt-1">{instruction}</p>
                    </li>
                  ))}
                </ol>
              </CardContent>
            </Card>
          </div>

          {/* Right column - Nutrition & Ordering */}
          <div className="space-y-6">
            {/* Order from restaurant card */}
            <Card className="bg-accent">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ShoppingBag className="h-5 w-5" />
                  Order This Dish
                </CardTitle>
              </CardHeader>
              <CardContent>
                {/* Show order form if restaurant selected */}
                {showOrderForm && selectedRestaurant ? (
                  <OrderForm
                    restaurantName={selectedRestaurant.name}
                    dishName={recipe.name}
                    onBack={handleBackToRestaurants}
                    onOrderComplete={handleOrderComplete}
                  />
                ) : (
                  // Show restaurant list
                  <div className="space-y-4">
                    <p className="text-sm text-muted-foreground mb-4">
                      Don't feel like cooking? Order this dish from a nearby restaurant!
                    </p>
                    
                    {/* Restaurant list */}
                    <div className="space-y-3">
                      {mockRestaurants.map((restaurant) => (
                        <div
                          key={restaurant.id}
                          className="p-4 bg-card rounded-lg border hover:border-primary transition-colors cursor-pointer"
                          onClick={() => handleRestaurantSelect(restaurant)}
                        >
                          <div className="flex justify-between items-start mb-2">
                            <h4 className="font-semibold">{restaurant.name}</h4>
                            <Badge variant="outline">{restaurant.price}</Badge>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Star className="h-3 w-3 fill-current text-primary" />
                              {restaurant.rating}
                            </span>
                            <span className="flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              {restaurant.distance}
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {restaurant.deliveryTime}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Nutrition information */}
            <Card>
              <CardHeader>
                <CardTitle>Nutrition Facts</CardTitle>
                <p className="text-sm text-muted-foreground">Per serving</p>
              </CardHeader>
              <CardContent className="space-y-3">
                {/* Calories - highlighted */}
                <div className="flex justify-between items-center py-3 border-b-2 border-primary">
                  <span className="font-semibold text-lg">Calories</span>
                  <span className="text-2xl font-bold text-primary">
                    {recipe.nutrition.calories}
                  </span>
                </div>

                {/* Other nutrients */}
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Protein</span>
                    <span className="font-semibold">{recipe.nutrition.protein}g</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Carbohydrates</span>
                    <span className="font-semibold">{recipe.nutrition.carbs}g</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Fat</span>
                    <span className="font-semibold">{recipe.nutrition.fat}g</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Fiber</span>
                    <span className="font-semibold">{recipe.nutrition.fiber}g</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Sodium</span>
                    <span className="font-semibold">{recipe.nutrition.sodium}mg</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Reviews summary */}
            <Card>
              <CardHeader>
                <CardTitle>User Reviews</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4 mb-4">
                  <div className="text-4xl font-bold">{recipe.rating}</div>
                  <div>
                    <div className="flex gap-1 mb-1">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${
                            i < Math.floor(recipe.rating)
                              ? "fill-primary text-primary"
                              : "text-muted"
                          }`}
                        />
                      ))}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Based on {recipe.reviews} reviews
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecipeDetail;
