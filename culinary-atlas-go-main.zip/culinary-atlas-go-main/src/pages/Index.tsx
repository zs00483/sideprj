// Homepage component with hero, about section, and cuisine categories
import { useNavigate } from "react-router-dom";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import About from "@/components/About";
import CuisineCard from "@/components/CuisineCard";
import { getAllCuisines, getRecipesByCuisine } from "@/data/recipes";
import indianCuisine from "@/assets/indian-cuisine.jpg";
import italianCuisine from "@/assets/italian-cuisine.jpg";
import thaiCuisine from "@/assets/thai-cuisine.jpg";
import mexicanCuisine from "@/assets/mexican-cuisine.jpg";
import japaneseCuisine from "@/assets/japanese-cuisine.jpg";
import chineseCuisine from "@/assets/chinese-cuisine.jpg";

const Index = () => {
  const navigate = useNavigate();

  // Handle search from hero component
  const handleSearch = (query: string) => {
    // Navigate to recipes page with search query
    navigate(`/recipes?search=${encodeURIComponent(query)}`);
  };

  // Map cuisine names to their images
  const cuisineImages: Record<string, string> = {
    Indian: indianCuisine,
    Italian: italianCuisine,
    Thai: thaiCuisine,
    Mexican: mexicanCuisine,
    Japanese: japaneseCuisine,
    Chinese: chineseCuisine,
  };

  // Get all unique cuisines from recipe data
  const cuisines = getAllCuisines();

  return (
    <div className="min-h-screen">
      {/* Header with logo */}
      <Header />
      
      {/* Hero section */}
      <Hero onSearch={handleSearch} />
      
      {/* About Us section */}
      <About />

      {/* Main content section */}
      <main className="container mx-auto px-4 py-12">
        {/* Section heading */}
        <div className="mb-8 text-center">
          <h2 className="text-4xl font-bold mb-3">Explore by Cuisine</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose from our collection of authentic recipes from around the world
          </p>
        </div>

        {/* Cuisine cards grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in">
          {cuisines.map((cuisine) => (
            <CuisineCard
              key={cuisine}
              name={cuisine}
              image={cuisineImages[cuisine]}
              recipeCount={getRecipesByCuisine(cuisine).length}
            />
          ))}
        </div>

        {/* CTA Section */}
        <div className="mt-16 text-center bg-card rounded-lg p-8 shadow-md">
          <h3 className="text-3xl font-bold mb-4">Start Your Culinary Journey</h3>
          <p className="text-lg text-muted-foreground mb-6 max-w-2xl mx-auto">
            Discover delicious recipes, track nutrition, and order from nearby restaurants all in one place
          </p>
          <button
            onClick={() => navigate("/recipes")}
            className="inline-flex items-center justify-center rounded-lg bg-primary px-8 py-3 text-lg font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Browse All Recipes
          </button>
        </div>
      </main>
    </div>
  );
};

export default Index;
