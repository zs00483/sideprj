// Recipes listing page with filters and search
import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import Header from "@/components/Header";
import RecipeCard from "@/components/RecipeCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, SlidersHorizontal } from "lucide-react";
import { recipes, getAllCuisines } from "@/data/recipes";

const Recipes = () => {
  // Get URL search params for filtering
  const [searchParams, setSearchParams] = useSearchParams();
  
  // State for filters
  const [searchQuery, setSearchQuery] = useState(searchParams.get("search") || "");
  const [selectedCuisine, setSelectedCuisine] = useState(
    searchParams.get("cuisine") || "all"
  );
  const [selectedDifficulty, setSelectedDifficulty] = useState("all");
  const [maxCalories, setMaxCalories] = useState("");

  // Get all cuisines for filter dropdown
  const cuisines = getAllCuisines();

  // Filter recipes based on search and filters
  const filteredRecipes = recipes.filter((recipe) => {
    // Search filter - check name, description, and cuisine
    const matchesSearch =
      !searchQuery ||
      recipe.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      recipe.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      recipe.cuisine.toLowerCase().includes(searchQuery.toLowerCase());

    // Cuisine filter
    const matchesCuisine =
      selectedCuisine === "all" ||
      recipe.cuisine.toLowerCase() === selectedCuisine.toLowerCase();

    // Difficulty filter
    const matchesDifficulty =
      selectedDifficulty === "all" ||
      recipe.difficulty.toLowerCase() === selectedDifficulty.toLowerCase();

    // Calorie filter
    const matchesCalories =
      !maxCalories || recipe.nutrition.calories <= parseInt(maxCalories);

    return matchesSearch && matchesCuisine && matchesDifficulty && matchesCalories;
  });

  // Update URL params when filters change
  useEffect(() => {
    const params = new URLSearchParams();
    if (searchQuery) params.set("search", searchQuery);
    if (selectedCuisine !== "all") params.set("cuisine", selectedCuisine);
    setSearchParams(params);
  }, [searchQuery, selectedCuisine, setSearchParams]);

  return (
    <div className="min-h-screen bg-background">
      {/* Header with logo */}
      <Header />
      
      {/* Page header */}
      <div className="bg-card border-b">
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-4xl font-bold mb-2">Recipe Collection</h1>
          <p className="text-lg text-muted-foreground">
            {filteredRecipes.length} recipes available
          </p>
        </div>
      </div>

      {/* Main content */}
      <div className="container mx-auto px-4 py-8">
        {/* Search and filters section */}
        <div className="mb-8 space-y-4">
          {/* Search bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search recipes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-12 text-lg"
            />
          </div>

          {/* Filter controls */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="h-5 w-5 text-muted-foreground" />
              <span className="font-semibold">Filters:</span>
            </div>

            {/* Cuisine filter */}
            <Select value={selectedCuisine} onValueChange={setSelectedCuisine}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Cuisine" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Cuisines</SelectItem>
                {cuisines.map((cuisine) => (
                  <SelectItem key={cuisine} value={cuisine.toLowerCase()}>
                    {cuisine}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Difficulty filter */}
            <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Difficulty" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Levels</SelectItem>
                <SelectItem value="easy">Easy</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="hard">Hard</SelectItem>
              </SelectContent>
            </Select>

            {/* Calorie filter */}
            <Input
              type="number"
              placeholder="Max calories"
              value={maxCalories}
              onChange={(e) => setMaxCalories(e.target.value)}
              className="w-full sm:w-[180px]"
            />

            {/* Reset filters button */}
            <Button
              variant="outline"
              onClick={() => {
                setSearchQuery("");
                setSelectedCuisine("all");
                setSelectedDifficulty("all");
                setMaxCalories("");
              }}
            >
              Reset
            </Button>
          </div>
        </div>

        {/* Recipe cards grid */}
        {filteredRecipes.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in">
            {filteredRecipes.map((recipe) => (
              <RecipeCard key={recipe.id} recipe={recipe} />
            ))}
          </div>
        ) : (
          // No results message
          <div className="text-center py-12">
            <p className="text-xl text-muted-foreground mb-4">
              No recipes found matching your criteria
            </p>
            <Button
              onClick={() => {
                setSearchQuery("");
                setSelectedCuisine("all");
                setSelectedDifficulty("all");
                setMaxCalories("");
              }}
            >
              Clear Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Recipes;
