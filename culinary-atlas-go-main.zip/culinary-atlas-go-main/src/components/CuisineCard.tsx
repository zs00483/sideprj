// Cuisine category card component
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";

interface CuisineCardProps {
  name: string; // Cuisine name (e.g., "Italian")
  image: string; // Image path from assets
  recipeCount: number; // Number of recipes in this cuisine
}

const CuisineCard = ({ name, image, recipeCount }: CuisineCardProps) => {
  return (
    // Link to filtered recipes page
    <Link to={`/recipes?cuisine=${name.toLowerCase()}`}>
      <Card className="group overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1 cursor-pointer">
        <CardContent className="p-0">
          {/* Cuisine image */}
          <div className="relative h-48 overflow-hidden">
            <img
              src={image}
              alt={`${name} cuisine`}
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110"
            />
            {/* Gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 to-transparent" />
            
            {/* Cuisine name and count */}
            <div className="absolute bottom-4 left-4 text-white">
              <h3 className="text-2xl font-bold">{name}</h3>
              <p className="text-sm text-white/90">{recipeCount} recipes</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
};

export default CuisineCard;
