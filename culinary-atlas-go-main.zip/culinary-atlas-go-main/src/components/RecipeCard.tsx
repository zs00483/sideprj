// Recipe card component for displaying recipe previews
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, Flame, Star } from "lucide-react";
import { Link } from "react-router-dom";
import { Recipe } from "@/data/recipes";

interface RecipeCardProps {
  recipe: Recipe; // Full recipe object
}

const RecipeCard = ({ recipe }: RecipeCardProps) => {
  // Import image dynamically based on recipe image field
  const getImagePath = () => {
    try {
      return new URL(`../assets/${recipe.image}.jpg`, import.meta.url).href;
    } catch {
      return ""; // Fallback if image not found
    }
  };

  return (
    // Link to recipe detail page
    <Link to={`/recipe/${recipe.id}`}>
      <Card className="group overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1 cursor-pointer h-full">
        <CardContent className="p-0">
          {/* Recipe image */}
          <div className="relative h-56 overflow-hidden">
            <img
              src={getImagePath()}
              alt={recipe.name}
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110"
            />
            
            {/* Difficulty badge */}
            <Badge
              className="absolute top-3 right-3 bg-card text-card-foreground"
              variant="secondary"
            >
              {recipe.difficulty}
            </Badge>

            {/* Cuisine badge */}
            <Badge
              className="absolute top-3 left-3 bg-primary text-primary-foreground"
            >
              {recipe.cuisine}
            </Badge>
          </div>

          {/* Recipe info */}
          <div className="p-4">
            <h3 className="text-xl font-bold mb-2 line-clamp-1">{recipe.name}</h3>
            <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
              {recipe.description}
            </p>

            {/* Quick stats */}
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              {/* Cook time */}
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                <span>{recipe.prepTime + recipe.cookTime}min</span>
              </div>

              {/* Calories */}
              <div className="flex items-center gap-1">
                <Flame className="h-4 w-4" />
                <span>{recipe.nutrition.calories} cal</span>
              </div>

              {/* Rating */}
              <div className="flex items-center gap-1">
                <Star className="h-4 w-4 fill-current text-primary" />
                <span>{recipe.rating}</span>
              </div>
            </div>
          </div>
        </CardContent>

        {/* Tags footer */}
        <CardFooter className="pt-0 pb-4 px-4">
          <div className="flex flex-wrap gap-2">
            {recipe.tags.slice(0, 3).map((tag) => (
              <Badge key={tag} variant="outline" className="text-xs">
                {tag}
              </Badge>
            ))}
          </div>
        </CardFooter>
      </Card>
    </Link>
  );
};

export default RecipeCard;
