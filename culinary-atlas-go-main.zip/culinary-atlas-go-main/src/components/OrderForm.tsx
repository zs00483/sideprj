// Order form component for restaurant ordering
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft } from "lucide-react";
import { toast } from "sonner";

interface OrderFormProps {
  restaurantName: string; // Name of selected restaurant
  dishName: string; // Name of the dish being ordered
  onBack: () => void; // Function to go back to restaurant list
  onOrderComplete: () => void; // Function to call when order is confirmed
}

const OrderForm = ({ restaurantName, dishName, onBack, onOrderComplete }: OrderFormProps) => {
  // Form state
  const [fullName, setFullName] = useState("");
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form fields
    if (!fullName.trim() || !address.trim() || !phone.trim()) {
      toast.error("Please fill in all fields");
      return;
    }

    // Validate phone number (basic validation)
    const phoneRegex = /^[\d\s\-\+\(\)]+$/;
    if (!phoneRegex.test(phone)) {
      toast.error("Please enter a valid phone number");
      return;
    }

    // Simulate API call
    setIsSubmitting(true);
    
    // Show loading toast
    toast.loading("Processing your order...");
    
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Clear loading toast
    toast.dismiss();
    
    // Show success message
    toast.success("Order confirmed!", {
      description: `Your ${dishName} from ${restaurantName} will arrive in 30-45 minutes.`,
      duration: 5000,
    });
    
    setIsSubmitting(false);
    
    // Call completion handler to close modal
    onOrderComplete();
  };

  return (
    <div className="space-y-6">
      {/* Back button */}
      <Button
        variant="ghost"
        onClick={onBack}
        className="gap-2 -ml-2"
        disabled={isSubmitting}
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Restaurants
      </Button>

      {/* Order details */}
      <div className="bg-muted/50 p-4 rounded-lg">
        <h3 className="font-semibold mb-1">Your Order</h3>
        <p className="text-sm text-muted-foreground">{dishName}</p>
        <p className="text-sm text-muted-foreground">from <span className="font-medium">{restaurantName}</span></p>
      </div>

      {/* Order form */}
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Full Name field */}
        <div className="space-y-2">
          <Label htmlFor="fullName">Full Name *</Label>
          <Input
            id="fullName"
            type="text"
            placeholder="Enter your full name"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            disabled={isSubmitting}
            required
          />
        </div>

        {/* Delivery Address field */}
        <div className="space-y-2">
          <Label htmlFor="address">Delivery Address *</Label>
          <Textarea
            id="address"
            placeholder="Enter your complete delivery address"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            disabled={isSubmitting}
            rows={3}
            required
          />
        </div>

        {/* Phone Number field */}
        <div className="space-y-2">
          <Label htmlFor="phone">Phone Number *</Label>
          <Input
            id="phone"
            type="tel"
            placeholder="+1 (555) 000-0000"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            disabled={isSubmitting}
            required
          />
        </div>

        {/* Submit button */}
        <Button
          type="submit"
          className="w-full bg-primary hover:bg-primary/90"
          size="lg"
          disabled={isSubmitting}
        >
          {isSubmitting ? "Processing..." : "Confirm Order"}
        </Button>

        {/* Helper text */}
        <p className="text-xs text-center text-muted-foreground">
          * All fields are required. Your information is kept secure.
        </p>
      </form>
    </div>
  );
};

export default OrderForm;
