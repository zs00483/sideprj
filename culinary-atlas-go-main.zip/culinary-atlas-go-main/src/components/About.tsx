// About Us section for homepage
import { Globe, ChefHat, ShoppingBag } from "lucide-react";

const About = () => {
  return (
    // About section with light background to stand out
    <section className="py-16 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          {/* Main heading */}
          <h2 className="text-4xl font-bold mb-4 animate-fade-in">
            Welcome to Global Gourmet
          </h2>
          
          {/* Main description */}
          <p className="text-lg text-muted-foreground mb-8 leading-relaxed animate-fade-in">
            Your passport to the world's most delicious flavors! We believe that food is a universal 
            language that connects us all. Here, you can explore authentic recipes from every corner 
            of the globe to cook at home, or simply order the finished dish from a great local 
            restaurant near you. Happy cooking (or ordering)!
          </p>

          {/* Feature highlights */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
            {/* Global Recipes */}
            <div className="bg-card p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow animate-scale-in">
              <div className="flex justify-center mb-4">
                <div className="p-3 bg-primary/10 rounded-full">
                  <Globe className="h-8 w-8 text-primary" />
                </div>
              </div>
              <h3 className="text-xl font-semibold mb-2">Global Recipes</h3>
              <p className="text-sm text-muted-foreground">
                Discover authentic dishes from cuisines around the world
              </p>
            </div>

            {/* Detailed Instructions */}
            <div className="bg-card p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow animate-scale-in" style={{ animationDelay: '0.1s' }}>
              <div className="flex justify-center mb-4">
                <div className="p-3 bg-primary/10 rounded-full">
                  <ChefHat className="h-8 w-8 text-primary" />
                </div>
              </div>
              <h3 className="text-xl font-semibold mb-2">Detailed Instructions</h3>
              <p className="text-sm text-muted-foreground">
                Step-by-step guidance with complete nutrition information
              </p>
            </div>

            {/* Order Local */}
            <div className="bg-card p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow animate-scale-in" style={{ animationDelay: '0.2s' }}>
              <div className="flex justify-center mb-4">
                <div className="p-3 bg-primary/10 rounded-full">
                  <ShoppingBag className="h-8 w-8 text-primary" />
                </div>
              </div>
              <h3 className="text-xl font-semibold mb-2">Order Local</h3>
              <p className="text-sm text-muted-foreground">
                Can't cook? Order from nearby restaurants with ease
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
