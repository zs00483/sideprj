// Header/Navigation component with logo and site title
import { Link } from "react-router-dom";
import Logo from "./Logo";

const Header = () => {
  return (
    // Fixed header with shadow for depth
    <header className="sticky top-0 z-50 w-full border-b bg-card shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          {/* Left side - Logo and brand name */}
          <Link to="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <Logo />
            <div>
              <h1 className="text-2xl font-bold text-foreground">Global Gourmet</h1>
              <p className="text-xs text-muted-foreground">World Flavors at Home</p>
            </div>
          </Link>

          {/* Right side - Navigation links */}
          <nav className="flex items-center gap-6">
            <Link
              to="/"
              className="text-sm font-medium text-foreground hover:text-primary transition-colors"
            >
              Home
            </Link>
            <Link
              to="/recipes"
              className="text-sm font-medium text-foreground hover:text-primary transition-colors"
            >
              Recipes
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
