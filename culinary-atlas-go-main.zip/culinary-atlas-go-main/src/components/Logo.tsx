// Logo component - Fork and spoon forming a globe shape
const Logo = () => {
  return (
    // SVG logo with fork and spoon forming a circle representing global cuisine
    <svg
      width="40"
      height="40"
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="text-primary"
    >
      {/* Outer circle representing the globe */}
      <circle
        cx="50"
        cy="50"
        r="45"
        stroke="currentColor"
        strokeWidth="3"
        fill="none"
      />
      
      {/* Fork on the left side */}
      <g transform="translate(25, 30)">
        {/* Fork handle */}
        <rect x="8" y="35" width="4" height="25" rx="2" fill="currentColor" />
        {/* Fork tines */}
        <rect x="2" y="20" width="2" height="20" rx="1" fill="currentColor" />
        <rect x="7" y="20" width="2" height="20" rx="1" fill="currentColor" />
        <rect x="12" y="20" width="2" height="20" rx="1" fill="currentColor" />
        <rect x="17" y="20" width="2" height="20" rx="1" fill="currentColor" />
        {/* Fork base connecting tines */}
        <rect x="2" y="20" width="18" height="3" rx="1" fill="currentColor" />
      </g>
      
      {/* Spoon on the right side */}
      <g transform="translate(55, 30)">
        {/* Spoon handle */}
        <rect x="8" y="35" width="4" height="25" rx="2" fill="currentColor" />
        {/* Spoon bowl */}
        <ellipse cx="10" cy="27" rx="8" ry="10" fill="currentColor" />
        {/* Inner spoon detail */}
        <ellipse cx="10" cy="27" rx="5" ry="7" fill="hsl(var(--background))" />
      </g>
    </svg>
  );
};

export default Logo;
