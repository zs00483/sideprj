// Hero section component with search functionality
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import heroImage from "@/assets/hero-food.jpg";

interface HeroProps {
  onSearch: (query: string) => void; // Callback function when user searches
}

const Hero = ({ onSearch }: HeroProps) => {
  // Handle search form submission
  const handleSearch = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const searchQuery = formData.get("search") as string;
    onSearch(searchQuery);
  };

  return (
    // Hero container with background image
    <section className="relative h-[500px] w-full overflow-hidden">
      {/* Background image with overlay */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${heroImage})`,
        }}
      >
        {/* Dark overlay for better text readability */}
        <div className="absolute inset-0 bg-foreground/60" />
      </div>

      {/* Hero content - centered text and search */}
      <div className="relative z-10 flex h-full flex-col items-center justify-center px-4 text-center">
        <h1 className="mb-4 text-5xl font-bold text-white md:text-6xl animate-fade-in">
          Discover Global Flavors
        </h1>
        <p className="mb-8 max-w-2xl text-xl text-white/90 animate-fade-in">
          Explore recipes from around the world with detailed nutrition info and order from nearby restaurants
        </p>

        {/* Search form */}
        <form
          onSubmit={handleSearch}
          className="flex w-full max-w-2xl gap-2 animate-scale-in"
        >
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="text"
              name="search"
              placeholder="Search for any recipe or cuisine..."
              className="h-14 pl-10 text-lg bg-card"
            />
          </div>
          <Button
            type="submit"
            size="lg"
            className="h-14 px-8 bg-primary hover:bg-primary/90"
          >
            Search
          </Button>
        </form>
      </div>
    </section>
  );
};

export default Hero;
